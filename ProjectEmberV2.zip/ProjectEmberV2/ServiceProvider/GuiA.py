import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import threading
import os
import sys
import time
import signal

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

PID_FILE = os.path.join(DATA_DIR, "process.pid")
SESSION_FILE = os.path.join(DATA_DIR, "session.txt")

process = None


def log(msg):
    console.insert(tk.END, msg + "\n")
    console.see(tk.END)


def is_running(pid):
    try:
        os.kill(pid, 0)
        return True
    except:
        return False


def save_session(path):
    with open(SESSION_FILE, "w", encoding="utf-8") as f:
        f.write(path)
    log(f"[SESSION SAVED] {path}")


def load_session():
    if os.path.exists(SESSION_FILE):
        path = open(SESSION_FILE, encoding="utf-8").read().strip()
        if os.path.exists(path):
            selected_file.set(path)
            log(f"[SESSION LOADED] {path}")


def run_script(path):
    global process

    try:
        compile(open(path, encoding="utf-8").read(), path, "exec")
    except Exception as e:
        log(f"[SYNTAX ERROR]\n{e}")
        return

    save_session(path)

    log(f"[STARTING] {path}")

    process = subprocess.Popen(
        [sys.executable, "-u", path],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1
    )

    with open(PID_FILE, "w") as f:
        f.write(str(process.pid))

    while True:
        line = process.stdout.readline()
        if line:
            log(line.rstrip())

        if process.poll() is not None:
            break

    log(f"[EXITED] Code {process.returncode}")

    if os.path.exists(PID_FILE):
        os.remove(PID_FILE)

    process = None


def start():
    path = selected_file.get()

    if not path:
        messagebox.showerror("Error", "Choose a .py file first")
        return

    if os.path.exists(PID_FILE):
        pid = int(open(PID_FILE).read())
        if is_running(pid):
            messagebox.showinfo("Running", "Script already running")
            return
        else:
            os.remove(PID_FILE)

    threading.Thread(target=run_script, args=(path,), daemon=True).start()


def stop():
    if not os.path.exists(PID_FILE):
        log("[INFO] No running process")
        return

    pid = int(open(PID_FILE).read())
    try:
        os.kill(pid, signal.SIGTERM)
        os.remove(PID_FILE)
        log("[STOPPED] Process terminated")
    except Exception as e:
        log(f"[ERROR] {e}")


def choose_file():
    path = filedialog.askopenfilename(
        filetypes=[("Python files", "*.py")]
    )
    if path:
        selected_file.set(path)
        log(f"[SELECTED] {path}")


def save_session_as():
    path = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Session files", "*.txt")]
    )
    if path:
        with open(path, "w", encoding="utf-8") as f:
            f.write(selected_file.get())
        log(f"[SESSION SAVED AS] {path}")


def detect_running():
    if os.path.exists(PID_FILE):
        pid = int(open(PID_FILE).read())
        if is_running(pid):
            log(f"[DETECTED RUNNING] PID {pid}")
        else:
            os.remove(PID_FILE)


# ---------------- GUI ----------------

root = tk.Tk()
root.title("Python Persistent Runner")
root.geometry("900x540")

selected_file = tk.StringVar()

top = tk.Frame(root)
top.pack(fill="x", padx=10, pady=6)

tk.Button(top, text="Choose .py", command=choose_file).pack(side="left")
tk.Label(top, textvariable=selected_file).pack(side="left", padx=10)

tk.Button(top, text="Run", width=10, command=start).pack(side="right", padx=5)
tk.Button(top, text="Stop", width=10, command=stop).pack(side="right")
tk.Button(top, text="Save Session As", command=save_session_as).pack(side="right", padx=5)

console = tk.Text(
    root,
    bg="black",
    fg="lime",
    insertbackground="white",
    font=("Consolas", 10)
)
console.pack(fill="both", expand=True, padx=10, pady=10)

load_session()
detect_running()

root.mainloop()
