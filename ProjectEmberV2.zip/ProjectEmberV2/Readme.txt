Instructions:
Install Requirements.txt
( pip install -r requirements.txt )

Enter projectEmber/ServiceProvider
Then Run in command prompt this
( GuiA.py or Python GuiA.py )

it should open a gui where you should click choose file and click Ai Service.py and then click run, wait for seconds or alot until it installs

pip install torch --index-url https://download.pytorch.org/whl/cu121 - if gpu
if cpu then
pip install torch --index-url https://download.pytorch.org/whl/cpu

Cpu is alot slower 😭😭😭⚠️