-- EmberA Roblox Plugin (Enhanced v2)
-- Connects Roblox Studio to the EmberA AI backend with full operation support

local HttpService = game:GetService("HttpService")
local Selection = game:GetService("Selection")

-- =========================
-- Configuration
-- =========================

local CONFIG = {
	server = "http://127.0.0.1:9600",
	heartbeatInterval = 3,
	pollInterval = 1,
	maxRetries = 3,
	retryDelay = 2,
}

local STATE = {
	isConnected = false,
	heartbeatAlive = false,
	pluginGuiOpen = false,
	scriptsCreated = 0,
	scriptsEdited = 0,
	operationsCompleted = 0,
	lastError = nil,
	autoReconnect = true,
}

-- =========================
-- UI Setup
-- =========================

local toolbar = plugin:CreateToolbar("EmberA AI")
local openButton = toolbar:CreateButton(
	"EmberA",
	"Open EmberA AI Assistant Panel",
	"rbxassetid://6031075934"
)

local widgetInfo = DockWidgetPluginGuiInfo.new(
	Enum.InitialDockState.Float,
	false,
	true,
	320,
	320,
	280,
	240
)

local widget = plugin:CreateDockWidgetPluginGui("EmberAWidget", widgetInfo)
widget.Title = "EmberA AI Assistant"

-- Main Frame
local frame = Instance.new("Frame")
frame.Size = UDim2.fromScale(1, 1)
frame.BackgroundColor3 = Color3.fromRGB(15, 18, 25)
frame.BorderSizePixel = 0
frame.Parent = widget

local frameCorner = Instance.new("UICorner")
frameCorner.CornerRadius = UDim.new(0, 8)
frameCorner.Parent = frame

-- Padding
local padding = Instance.new("UIPadding")
padding.PaddingTop = UDim.new(0, 16)
padding.PaddingBottom = UDim.new(0, 16)
padding.PaddingLeft = UDim.new(0, 16)
padding.PaddingRight = UDim.new(0, 16)
padding.Parent = frame

-- Header
local header = Instance.new("TextLabel")
header.Size = UDim2.new(1, 0, 0, 24)
header.Position = UDim2.new(0, 0, 0, 0)
header.BackgroundTransparency = 1
header.Text = "EmberA AI Assistant"
header.Font = Enum.Font.GothamBold
header.TextSize = 18
header.TextColor3 = Color3.fromRGB(240, 240, 240)
header.TextXAlignment = Enum.TextXAlignment.Left
header.Parent = frame

-- Status Container
local statusContainer = Instance.new("Frame")
statusContainer.Size = UDim2.new(1, 0, 0, 120)
statusContainer.Position = UDim2.new(0, 0, 0, 40)
statusContainer.BackgroundColor3 = Color3.fromRGB(25, 30, 40)
statusContainer.BorderSizePixel = 0
statusContainer.Parent = frame

local statusCorner = Instance.new("UICorner")
statusCorner.CornerRadius = UDim.new(0, 8)
statusCorner.Parent = statusContainer

-- Status Label
local statusLabel = Instance.new("TextLabel")
statusLabel.Size = UDim2.new(1, -20, 0, 28)
statusLabel.Position = UDim2.new(0, 10, 0, 10)
statusLabel.BackgroundTransparency = 1
statusLabel.Text = "Status: Disconnected"
statusLabel.Font = Enum.Font.GothamMedium
statusLabel.TextSize = 15
statusLabel.TextColor3 = Color3.fromRGB(255, 120, 120)
statusLabel.TextXAlignment = Enum.TextXAlignment.Left
statusLabel.Parent = statusContainer

-- Stats Label
local statsLabel = Instance.new("TextLabel")
statsLabel.Size = UDim2.new(1, -20, 0, 20)
statsLabel.Position = UDim2.new(0, 10, 0, 42)
statsLabel.BackgroundTransparency = 1
statsLabel.Text = "Scripts: 0 Created | 0 Edited"
statsLabel.Font = Enum.Font.Gotham
statsLabel.TextSize = 13
statsLabel.TextColor3 = Color3.fromRGB(160, 160, 160)
statsLabel.TextXAlignment = Enum.TextXAlignment.Left
statsLabel.Parent = statusContainer

-- Operations Label
local opsLabel = Instance.new("TextLabel")
opsLabel.Size = UDim2.new(1, -20, 0, 20)
opsLabel.Position = UDim2.new(0, 10, 0, 64)
opsLabel.BackgroundTransparency = 1
opsLabel.Text = "Operations: 0"
opsLabel.Font = Enum.Font.Gotham
opsLabel.TextSize = 13
opsLabel.TextColor3 = Color3.fromRGB(160, 160, 160)
opsLabel.TextXAlignment = Enum.TextXAlignment.Left
opsLabel.Parent = statusContainer

-- Server Label
local serverLabel = Instance.new("TextLabel")
serverLabel.Size = UDim2.new(1, -20, 0, 18)
serverLabel.Position = UDim2.new(0, 10, 0, 86)
serverLabel.BackgroundTransparency = 1
serverLabel.Text = "Server: " .. CONFIG.server
serverLabel.Font = Enum.Font.Code
serverLabel.TextSize = 11
serverLabel.TextColor3 = Color3.fromRGB(120, 120, 120)
serverLabel.TextXAlignment = Enum.TextXAlignment.Left
serverLabel.Parent = statusContainer

-- Version Label
local versionLabel = Instance.new("TextLabel")
versionLabel.Size = UDim2.new(1, -20, 0, 16)
versionLabel.Position = UDim2.new(0, 10, 0, 102)
versionLabel.BackgroundTransparency = 1
versionLabel.Text = "v2.0 - Full Operations"
versionLabel.Font = Enum.Font.Code
versionLabel.TextSize = 10
versionLabel.TextColor3 = Color3.fromRGB(100, 100, 100)
versionLabel.TextXAlignment = Enum.TextXAlignment.Left
versionLabel.Parent = statusContainer

-- Connect Button
local connectButton = Instance.new("TextButton")
connectButton.Size = UDim2.new(1, 0, 0, 44)
connectButton.Position = UDim2.new(0, 0, 0, 176)
connectButton.Text = "🔌 Connect to Server"
connectButton.Font = Enum.Font.GothamBold
connectButton.TextSize = 15
connectButton.BackgroundColor3 = Color3.fromRGB(34, 197, 94)
connectButton.TextColor3 = Color3.fromRGB(255, 255, 255)
connectButton.BorderSizePixel = 0
connectButton.AutoButtonColor = false
connectButton.Parent = frame

local connectCorner = Instance.new("UICorner")
connectCorner.CornerRadius = UDim.new(0, 8)
connectCorner.Parent = connectButton

-- Disconnect Button
local disconnectButton = Instance.new("TextButton")
disconnectButton.Size = UDim2.new(1, 0, 0, 44)
disconnectButton.Position = UDim2.new(0, 0, 0, 176)
disconnectButton.Text = "🔴 Disconnect"
disconnectButton.Font = Enum.Font.GothamBold
disconnectButton.TextSize = 15
disconnectButton.BackgroundColor3 = Color3.fromRGB(239, 68, 68)
disconnectButton.TextColor3 = Color3.fromRGB(255, 255, 255)
disconnectButton.BorderSizePixel = 0
disconnectButton.AutoButtonColor = false
disconnectButton.Visible = false
disconnectButton.Parent = frame

local disconnectCorner = Instance.new("UICorner")
disconnectCorner.CornerRadius = UDim.new(0, 8)
disconnectCorner.Parent = disconnectButton

-- Settings Button
local settingsButton = Instance.new("TextButton")
settingsButton.Size = UDim2.new(1, 0, 0, 36)
settingsButton.Position = UDim2.new(0, 0, 0, 232)
settingsButton.Text = "⚙️ Settings"
settingsButton.Font = Enum.Font.Gotham
settingsButton.TextSize = 13
settingsButton.BackgroundColor3 = Color3.fromRGB(40, 45, 55)
settingsButton.TextColor3 = Color3.fromRGB(200, 200, 200)
settingsButton.BorderSizePixel = 0
settingsButton.AutoButtonColor = false
settingsButton.Parent = frame

local settingsCorner = Instance.new("UICorner")
settingsCorner.CornerRadius = UDim.new(0, 8)
settingsCorner.Parent = settingsButton

-- =========================
-- Status Management
-- =========================

local function updateUI()
	if STATE.isConnected then
		statusLabel.Text = "Status: Connected ✅"
		statusLabel.TextColor3 = Color3.fromRGB(34, 197, 94)
		connectButton.Visible = false
		disconnectButton.Visible = true
		openButton.Icon = "rbxassetid://6031094678" -- Green checkmark
	else
		statusLabel.Text = "Status: Disconnected ❌"
		statusLabel.TextColor3 = Color3.fromRGB(239, 68, 68)
		connectButton.Visible = true
		disconnectButton.Visible = false
		openButton.Icon = "rbxassetid://6031075934" -- Default icon
		
		if STATE.lastError then
			statusLabel.Text = "Status: Error - " .. STATE.lastError
		end
	end
	
	statsLabel.Text = string.format("Scripts: %d Created | %d Edited", STATE.scriptsCreated, STATE.scriptsEdited)
	opsLabel.Text = string.format("Operations: %d", STATE.operationsCompleted)
end

local function setConnected(connected, errorMsg)
	STATE.isConnected = connected
	STATE.heartbeatAlive = connected
	STATE.lastError = errorMsg
	updateUI()
	
	if connected then
		print("[EmberA] Connected to AI backend successfully!")
	else
		warn("[EmberA] Disconnected from backend" .. (errorMsg and (": " .. errorMsg) or ""))
	end
end

-- =========================
-- Network Communication
-- =========================

local function sendHeartbeat()
	if not STATE.heartbeatAlive then return end
	
	local success, result = pcall(function()
		return HttpService:PostAsync(
			CONFIG.server .. "/pluginConnected",
			"",
			Enum.HttpContentType.ApplicationJson
		)
	end)
	
	if not success then
		-- Connection lost
		if STATE.isConnected then
			setConnected(false, "Lost connection")
		end
		
		-- Auto-reconnect attempt
		if STATE.autoReconnect then
			task.wait(CONFIG.retryDelay)
			tryConnect(true)
		end
	end
end

local function tryConnect(isRetry)
	if STATE.isConnected and not isRetry then return end
	
	local retries = 0
	local success = false
	
	while retries < CONFIG.maxRetries and not success do
		local ok, err = pcall(function()
			HttpService:PostAsync(
				CONFIG.server .. "/pluginConnected",
				"",
				Enum.HttpContentType.ApplicationJson
			)
		end)
		
		if ok then
			success = true
			setConnected(true, nil)
		else
			retries = retries + 1
			if retries < CONFIG.maxRetries then
				task.wait(CONFIG.retryDelay)
			else
				setConnected(false, "Connection failed")
			end
		end
	end
end

local function disconnect()
	STATE.heartbeatAlive = false
	setConnected(false, nil)
end

-- =========================
-- Helper Functions
-- =========================

local function parseService(servicePath)
	-- Handle nested services like "StarterPlayer.StarterPlayerScripts"
	local parts = string.split(servicePath, ".")
	local current = game:GetService(parts[1])
	
	for i = 2, #parts do
		current = current:FindFirstChild(parts[i])
		if not current then
			warn("[EmberA] Could not find:", parts[i], "in", parts[i-1])
			return nil
		end
	end
	
	return current
end

local function findInstance(path)
	-- Try to find an instance by path
	if not path or path == "" then
		-- Use current selection if no path provided
		local selected = Selection:Get()
		if #selected > 0 then
			return selected[1]
		end
		return nil
	end
	
	-- Parse the path
	local parts = string.split(path, ".")
	local current = game:GetService(parts[1])
	
	for i = 2, #parts do
		current = current:FindFirstChild(parts[i])
		if not current then
			warn("[EmberA] Could not find:", parts[i])
			return nil
		end
	end
	
	return current
end

local function applyProperty(instance, propName, propValue)
	-- Parse and apply property value
	local success, err = pcall(function()
		-- Handle special types
		if propValue:match("Color3%.fromRGB") then
			local r, g, b = propValue:match("(%d+),%s*(%d+),%s*(%d+)")
			instance[propName] = Color3.fromRGB(tonumber(r), tonumber(g), tonumber(b))
		elseif propValue:match("Vector3%.new") then
			local x, y, z = propValue:match("([%d%-]+),%s*([%d%-]+),%s*([%d%-]+)")
			instance[propName] = Vector3.new(tonumber(x), tonumber(y), tonumber(z))
		elseif propValue:match("Enum%.") then
			-- Handle enums
			local enumPath = propValue:gsub("Enum%.", "")
			local enumParts = string.split(enumPath, ".")
			instance[propName] = Enum[enumParts[1]][enumParts[2]]
		elseif propValue == "true" then
			instance[propName] = true
		elseif propValue == "false" then
			instance[propName] = false
		elseif propValue:match('^".*"$') then
			-- String value
			instance[propName] = propValue:gsub('"', '')
		else
			-- Number value
			instance[propName] = tonumber(propValue)
		end
	end)
	
	if not success then
		warn("[EmberA] Error setting property", propName, ":", err)
	end
end

-- =========================
-- Operation Handlers
-- =========================

local function handleCreateScript(data)
	local success, err = pcall(function()
		local serviceName = data.service
		local scriptName = data.scriptName
		local scriptType = data.scriptType or "Script"
		local scriptSource = data.scriptSource
		
		-- Validation
		if not serviceName or not scriptName or not scriptSource then
			warn("[EmberA] Invalid script request - missing required fields")
			return
		end
		
		-- Get parent container
		local parent = parseService(serviceName)
		if not parent then
			warn("[EmberA] Service not found:", serviceName)
			return
		end
		
		-- Remove existing script with same name
		local existing = parent:FindFirstChild(scriptName)
		if existing and existing:IsA("LuaSourceContainer") then
			existing:Destroy()
			print("[EmberA] Replaced existing script:", scriptName)
		end
		
		-- Create new script
		local scriptObj = Instance.new(scriptType)
		scriptObj.Name = scriptName
		scriptObj.Source = scriptSource
		scriptObj.Parent = parent
		
		-- Update stats
		STATE.scriptsCreated = STATE.scriptsCreated + 1
		STATE.operationsCompleted = STATE.operationsCompleted + 1
		updateUI()
		
		-- Select the new script
		Selection:Set({scriptObj})
		
		-- Success notification
		print(string.format("[EmberA] ✅ Created %s '%s' in %s", scriptType, scriptName, serviceName))
	end)
	
	if not success then
		warn("[EmberA] Error creating script:", err)
	end
end

local function handleEditScript(data)
	local success, err = pcall(function()
		local scriptPath = data.scriptPath
		local newSource = data.newSource
		
		if not newSource then
			warn("[EmberA] No source code provided for edit")
			return
		end
		
		-- Find the script to edit
		local scriptObj = findInstance(scriptPath)
		
		if not scriptObj then
			warn("[EmberA] Could not find script to edit:", scriptPath or "no path provided")
			warn("[EmberA] Tip: Select the script in Studio or provide its full path")
			return
		end
		
		if not scriptObj:IsA("LuaSourceContainer") then
			warn("[EmberA] Selected object is not a script:", scriptObj:GetFullName())
			return
		end
		
		-- Apply the edit
		scriptObj.Source = newSource
		
		-- Update stats
		STATE.scriptsEdited = STATE.scriptsEdited + 1
		STATE.operationsCompleted = STATE.operationsCompleted + 1
		updateUI()
		
		-- Select the edited script
		Selection:Set({scriptObj})
		
		-- Success notification
		print(string.format("[EmberA] ✅ Edited script: %s", scriptObj.Name))
	end)
	
	if not success then
		warn("[EmberA] Error editing script:", err)
	end
end

local function handleModifyProperties(data)
	local success, err = pcall(function()
		local instancePath = data.instancePath
		local properties = data.properties
		
		if not properties or type(properties) ~= "table" then
			warn("[EmberA] No properties provided")
			return
		end
		
		-- Find the instance
		local instance = findInstance(instancePath)
		
		if not instance then
			warn("[EmberA] Could not find instance:", instancePath or "no path provided")
			return
		end
		
		-- Apply each property
		for propName, propValue in pairs(properties) do
			applyProperty(instance, propName, propValue)
			print(string.format("[EmberA] Set %s.%s = %s", instance.Name, propName, propValue))
		end
		
		-- Update stats
		STATE.operationsCompleted = STATE.operationsCompleted + 1
		updateUI()
		
		-- Select the modified instance
		Selection:Set({instance})
		
		print(string.format("[EmberA] ✅ Modified %d properties on %s", #properties, instance.Name))
	end)
	
	if not success then
		warn("[EmberA] Error modifying properties:", err)
	end
end

local function handleCreateInstance(data)
	local success, err = pcall(function()
		local instanceType = data.instanceType
		local instanceName = data.instanceName
		local parentPath = data.parentPath
		local properties = data.properties or {}
		
		if not instanceType or not instanceName then
			warn("[EmberA] Invalid instance creation request")
			return
		end
		
		-- Find parent
		local parent = findInstance(parentPath)
		if not parent then
			warn("[EmberA] Could not find parent:", parentPath)
			return
		end
		
		-- Create the instance
		local newInstance = Instance.new(instanceType)
		newInstance.Name = instanceName
		
		-- Apply properties
		for propName, propValue in pairs(properties) do
			applyProperty(newInstance, propName, propValue)
		end
		
		-- Parent last (Roblox best practice)
		newInstance.Parent = parent
		
		-- Update stats
		STATE.operationsCompleted = STATE.operationsCompleted + 1
		updateUI()
		
		-- Select the new instance
		Selection:Set({newInstance})
		
		print(string.format("[EmberA] ✅ Created %s '%s' in %s", instanceType, instanceName, parent:GetFullName()))
	end)
	
	if not success then
		warn("[EmberA] Error creating instance:", err)
	end
end

local function handleDeleteInstance(data)
	local success, err = pcall(function()
		local instancePath = data.instancePath
		
		-- Find the instance
		local instance = findInstance(instancePath)
		
		if not instance then
			warn("[EmberA] Could not find instance to delete:", instancePath or "no path provided")
			return
		end
		
		local instanceName = instance.Name
		instance:Destroy()
		
		-- Update stats
		STATE.operationsCompleted = STATE.operationsCompleted + 1
		updateUI()
		
		print(string.format("[EmberA] ✅ Deleted %s", instanceName))
	end)
	
	if not success then
		warn("[EmberA] Error deleting instance:", err)
	end
end

local function handleCloneInstance(data)
	local success, err = pcall(function()
		local instancePath = data.instancePath
		
		-- Find the instance
		local instance = findInstance(instancePath)
		
		if not instance then
			warn("[EmberA] Could not find instance to clone:", instancePath or "no path provided")
			return
		end
		
		-- Clone it
		local clone = instance:Clone()
		clone.Name = instance.Name .. "Clone"
		clone.Parent = instance.Parent
		
		-- Update stats
		STATE.operationsCompleted = STATE.operationsCompleted + 1
		updateUI()
		
		-- Select the clone
		Selection:Set({clone})
		
		print(string.format("[EmberA] ✅ Cloned %s", instance.Name))
	end)
	
	if not success then
		warn("[EmberA] Error cloning instance:", err)
	end
end

-- =========================
-- Main Operation Router
-- =========================

local function applyOperation(data)
	if not data or not data.operation then
		warn("[EmberA] Invalid operation data")
		return
	end
	
	local operation = data.operation
	
	if operation == "create_script" then
		handleCreateScript(data)
	elseif operation == "edit_script" then
		handleEditScript(data)
	elseif operation == "modify_properties" then
		handleModifyProperties(data)
	elseif operation == "create_instance" then
		handleCreateInstance(data)
	elseif operation == "delete_instance" then
		handleDeleteInstance(data)
	elseif operation == "clone_instance" then
		handleCloneInstance(data)
	else
		warn("[EmberA] Unknown operation:", operation)
	end
end

local function pollServer()
	if not STATE.isConnected then return end
	
	local success, response = pcall(function()
		return HttpService:GetAsync(CONFIG.server .. "/getPendingScriptRequest")
	end)
	
	if not success then
		-- Polling failed, connection might be lost
		return
	end
	
	if not response or response == "{}" or response == "" then
		return
	end
	
	-- Parse and apply
	local ok, data = pcall(function()
		return HttpService:JSONDecode(response)
	end)
	
	if ok and data and next(data) then
		applyOperation(data)
	end
end

-- =========================
-- Background Tasks
-- =========================

-- Heartbeat loop
task.spawn(function()
	while true do
		sendHeartbeat()
		task.wait(CONFIG.heartbeatInterval)
	end
end)

-- Polling loop
task.spawn(function()
	while true do
		pollServer()
		task.wait(CONFIG.pollInterval)
	end
end)

-- =========================
-- UI Event Handlers
-- =========================

connectButton.MouseButton1Click:Connect(function()
	connectButton.Text = "🔄 Connecting..."
	connectButton.BackgroundColor3 = Color3.fromRGB(250, 204, 21)
	tryConnect(false)
	task.wait(0.5)
	connectButton.Text = "🔌 Connect to Server"
	connectButton.BackgroundColor3 = Color3.fromRGB(34, 197, 94)
end)

disconnectButton.MouseButton1Click:Connect(function()
	disconnect()
end)

settingsButton.MouseButton1Click:Connect(function()
	STATE.autoReconnect = not STATE.autoReconnect
	settingsButton.Text = STATE.autoReconnect and "⚙️ Settings (Auto-reconnect: ON)" or "⚙️ Settings (Auto-reconnect: OFF)"
end)

openButton.Click:Connect(function()
	STATE.pluginGuiOpen = not STATE.pluginGuiOpen
	widget.Enabled = STATE.pluginGuiOpen
end)

plugin.Unloading:Connect(function()
	disconnect()
	print("[EmberA] Plugin unloaded. Stats:")
	print(string.format("  Scripts Created: %d", STATE.scriptsCreated))
	print(string.format("  Scripts Edited: %d", STATE.scriptsEdited))
	print(string.format("  Total Operations: %d", STATE.operationsCompleted))
end)

-- =========================
-- Initialization
-- =========================

updateUI()
print("[EmberA] Plugin v2.0 loaded with full operation support")
print("[EmberA] Features: Create, Edit, Modify, Delete, Clone")
print("[EmberA] Backend server:", CONFIG.server)
print("[EmberA] Click the toolbar button to open the panel")