import uuid
import torch
import re
import time
import os
from pathlib import Path
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import uvicorn
import sys

sys.stdout.reconfigure(encoding="utf-8")

model_id = "Qwen/Qwen2.5-Coder-3B-Instruct"
max_new_tokens = 768
max_new_tokens_hardthink = 1536  # Double for hard think mode
device = "cuda" if torch.cuda.is_available() else "cpu"

# ----------------------------
# BRAIN LOADING SYSTEM
# ----------------------------

def load_brain_files():
    """Load all brain knowledge files from ProjectEmber/Brain directory"""
    brain_dir = Path("ProjectEmber/Brain")
    brains = {
        "brain1": "",
        "brain2": "",
        "brain3": "",
        "brain4": "",
        "brain5": ""  # NEW: Ultimate mastery brain
    }
    
    brain_files = {
        "brain1": "brain1_general.txt",
        "brain2": "brain2_luau_implemented.txt",
        "brain3": "brain3_luau_advancer.txt",
        "brain4": "brain4_luau_ultimate.txt",
        "brain5": "brain5_ultimate_mastery.txt"  # NEW: Claude-level expertise
    }
    
    for brain_name, filename in brain_files.items():
        brain_path = brain_dir / filename
        if brain_path.exists():
            try:
                with open(brain_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    brains[brain_name] = content
                    print(f"[EmberA] ✓ Loaded {brain_name}: {filename} ({len(content):,} chars)")
            except Exception as e:
                print(f"[EmberA] ✗ Warning: Could not load {brain_name}: {e}")
        else:
            print(f"[EmberA] ✗ Warning: {filename} not found at {brain_path}")
    
    return brains

# Load brains at startup
print("\n" + "="*70)
print("  EMBERA AI BRAIN LOADING SYSTEM")
print("="*70)
BRAINS = load_brain_files()
loaded_count = sum(1 for b in BRAINS.values() if b)
print(f"\n[EmberA] Brain loading complete: {loaded_count}/5 brains loaded")
print("="*70 + "\n")

# ----------------------------
# ENHANCED PROMPTS WITH BRAINS
# ----------------------------

def build_normal_prompt():
    """Build the normal conversation prompt with relevant brain knowledge"""
    base_prompt = """You are EmberA, an expert Roblox development assistant with deep knowledge of Luau programming.

Your role:
- Provide clear, accurate technical guidance about Roblox development
- Answer questions about Luau scripting, Roblox API, game design, and best practices
- Help debug issues and explain concepts thoroughly
- Structure your responses clearly and professionally
- Use a friendly but expert tone

MESSAGE STRUCTURE GUIDELINES:
- Start with a clear, direct answer
- Break down complex topics into logical sections
- Use code blocks (```lua) for ALL code examples, even short snippets
- Explain WHY things work, not just HOW
- Keep explanations concise but complete

CODE FORMATTING RULES:
- ALWAYS wrap code in ```lua code blocks
- Include helpful comments in code examples
- Format code properly with indentation
- Show complete, working examples when helpful

Example structured response:
"To make a part transparent, you need to modify its Transparency property. Here's how:

```lua
local part = workspace.Part
part.Transparency = 0.5  -- 0 = opaque, 1 = invisible
```

The Transparency property accepts values from 0 to 1, where 0 is completely opaque and 1 is fully invisible."

DO NOT generate full scripts unless explicitly asked to create/generate/write a script.
For explanations and teaching, use clear code examples in code blocks.

"""
    
    # Add brain knowledge - prioritize most relevant
    knowledge_sections = []
    
    if BRAINS["brain1"]:
        knowledge_sections.append("## Core Programming Principles\n" + BRAINS["brain1"][:50000])
    
    if BRAINS["brain2"]:
        knowledge_sections.append("## Luau Language Fundamentals\n" + BRAINS["brain2"][:50000])
    
    if BRAINS["brain3"]:
        knowledge_sections.append("## Advanced Techniques Reference\n" + BRAINS["brain3"][:30000])
    
    if knowledge_sections:
        base_prompt += "\n\n---\n\nKNOWLEDGE BASE:\n\n" + "\n\n".join(knowledge_sections)
    
    return base_prompt


def build_hardthink_prompt():
    """Build the Hard Think mode prompt for deep reasoning with ALL brains"""
    base_prompt = """You are EmberA in HARD THINK MODE - an advanced reasoning mode for complex Roblox development questions.

HARD THINK MODE PROTOCOL:
When in this mode, you should:

1. **Deep Analysis**: Break down complex problems into fundamental components
2. **Multiple Perspectives**: Consider different approaches and their trade-offs
3. **Best Practices**: Apply advanced architectural patterns and optimization techniques
4. **Comprehensive Explanations**: Provide detailed reasoning with clear structure
5. **Edge Cases**: Identify potential issues and mitigation strategies
6. **Performance Impact**: Analyze performance implications of different solutions
7. **Scalability**: Consider how solutions scale with game complexity

RESPONSE STRUCTURE (Use this format):
1. **Problem Understanding**: Restate and clarify the question
2. **Approach Overview**: Outline the solution strategy
3. **Detailed Explanation**: Step-by-step breakdown with code examples
4. **Considerations**: Edge cases, performance, best practices
5. **Summary**: Key takeaways and recommendations

CODE PRESENTATION:
- ALWAYS use ```lua code blocks for all code examples
- Include detailed comments explaining complex logic
- Show both basic and advanced implementations
- Demonstrate best practices in code structure
- Format code with proper indentation

Guidelines:
- Structure responses logically with clear sections
- Use technical terminology with explanations
- Provide multiple code examples showing progression
- Think through architectural decisions systematically
- Consider security, performance, and maintainability
- Reference Roblox API limitations and constraints

Remember: Hard Think Mode delivers comprehensive understanding through structured, detailed responses.

"""
    
    # Add ALL brain knowledge for maximum depth
    knowledge_sections = []
    
    if BRAINS["brain1"]:
        knowledge_sections.append("## Core Programming Principles\n" + BRAINS["brain1"][:50000])
    
    if BRAINS["brain2"]:
        knowledge_sections.append("## Luau Language Mastery\n" + BRAINS["brain2"][:60000])
    
    if BRAINS["brain3"]:
        knowledge_sections.append("## Advanced Techniques & Patterns\n" + BRAINS["brain3"][:80000])
    
    if BRAINS["brain4"]:
        knowledge_sections.append("## Expert Optimization & Architecture\n" + BRAINS["brain4"][:100000])
    
    if BRAINS["brain5"]:
        # Brain 5 is the ultimate knowledge base - use generously
        knowledge_sections.append("## ULTIMATE LUAU MASTERY - Complete API Reference\n" + BRAINS["brain5"][:150000])
    
    if knowledge_sections:
        base_prompt += "\n\n---\n\nDEEP KNOWLEDGE BASE:\n\n" + "\n\n".join(knowledge_sections)
        base_prompt += "\n\n---\n\nApply this comprehensive knowledge to provide the most insightful response possible."
    
    return base_prompt


def build_script_prompt():
    """Build the script generation prompt with ALL brain knowledge"""
    base_prompt = """You are EmberA, a senior Roblox Luau engineer specializing in production-ready scripts.

CRITICAL RULES FOR SCRIPT GENERATION:
1. Output ONLY raw Luau source code - nothing else
2. NO markdown formatting, NO backticks (```), NO explanations outside the code
3. Start directly with the code (no preamble)
4. Use clear -- comments to explain logic within the code
5. Follow Roblox best practices and modern Luau syntax
6. Include proper error handling where appropriate
7. Use descriptive variable names
8. Optimize for performance and readability
9. Structure code logically with clear sections
10. Add header comments explaining what the script does

Code quality standards:
- Use local variables appropriately
- Implement proper type safety when beneficial
- Include :GetService() for Roblox services
- Use WaitForChild() for critical instances
- Add helpful -- comments for complex sections
- Structure code with clear separation of concerns
- Include configuration sections at the top when relevant

Example output format:
--[[
    Script Name: DoorScript
    Description: Opens and closes a door when clicked
    Author: EmberA
]]

local TweenService = game:GetService("TweenService")
local door = script.Parent

-- Configuration
local OPEN_POSITION = door.Position + Vector3.new(0, 5, 0)
local TWEEN_TIME = 1

-- Rest of code...

Remember: Your output will be directly inserted as a Roblox script. Write clean, professional code.

"""
    
    # Add ALL brain knowledge for maximum code quality
    knowledge_sections = []
    
    if BRAINS["brain1"]:
        knowledge_sections.append("## Programming Principles\n" + BRAINS["brain1"][:40000])
    
    if BRAINS["brain2"]:
        knowledge_sections.append("## Luau Language Reference\n" + BRAINS["brain2"][:60000])
    
    if BRAINS["brain3"]:
        knowledge_sections.append("## Advanced Patterns & Techniques\n" + BRAINS["brain3"][:80000])
    
    if BRAINS["brain4"]:
        knowledge_sections.append("## Performance & Optimization\n" + BRAINS["brain4"][:100000])
    
    if BRAINS["brain5"]:
        knowledge_sections.append("## Ultimate Luau Mastery\n" + BRAINS["brain5"][:120000])
    
    if knowledge_sections:
        base_prompt += "\n\n---\n\nEXPERT KNOWLEDGE BASE:\n\n" + "\n\n".join(knowledge_sections)
        base_prompt += "\n\n---\n\nApply this knowledge to write the highest quality Luau code possible."
    
    return base_prompt


def build_hardthink_script_prompt():
    """Build the Hard Think script generation prompt - maximum expertise"""
    base_prompt = """You are EmberA in HARD THINK SCRIPT MODE - producing enterprise-grade Roblox Luau code at Claude Sonnet 4.5 / Opus level.

ULTRA-CRITICAL RULES:
1. Output ONLY raw Luau source code - nothing else
2. NO markdown, NO backticks (```), NO explanations outside comments
3. This is Hard Think Mode - write MORE comprehensive, MORE optimized code
4. Include extensive -- comments explaining complex logic and design decisions
5. Apply advanced optimization techniques and architectural patterns
6. Consider edge cases and error handling thoroughly
7. Use modern Luau best practices and type annotations where beneficial
8. Structure code for maximum maintainability and performance

Enhanced Quality Standards:
- Add detailed header documentation
- Implement robust error handling with pcall where appropriate
- Use module patterns for complex functionality
- Apply performance optimizations (object pooling, efficient loops, etc.)
- Include detailed comments on WHY certain approaches were chosen
- Consider memory efficiency and garbage collection
- Use proper event cleanup and connection management
- Implement type checking where it adds value
- Follow SOLID principles where applicable
- Add configuration sections for easy customization
- Structure code with clear separation of concerns

Script Structure Template:
--[[
    ╔═══════════════════════════════════════╗
    ║  [Script Name]                        ║
    ║  Hard Think Mode - Enterprise Grade   ║
    ╚═══════════════════════════════════════╝
    
    Description: [What this script does]
    
    Features:
    - [Feature 1]
    - [Feature 2]
    
    Performance: [Optimizations applied]
    Author: EmberA
]]

-- Services
local ServiceName = game:GetService("ServiceName")

-- Configuration
local CONFIG = {
    -- Settings here
}

-- State
local state = {}

-- Functions
-- [Well-documented functions]

-- Initialization
-- [Clean initialization logic]

Hard Think Mode means:
- More comprehensive solutions with advanced features
- Better optimization and performance considerations
- More detailed comments explaining design decisions
- More robust error handling and edge case coverage
- Better code organization with clear patterns
- Future-proof, scalable design

Remember: This code should be production-ready and showcase expert-level Roblox engineering.

"""
    
    # Add ALL brain knowledge - maximum expertise
    knowledge_sections = []
    
    if BRAINS["brain1"]:
        knowledge_sections.append("## Advanced Programming Principles\n" + BRAINS["brain1"][:50000])
    
    if BRAINS["brain2"]:
        knowledge_sections.append("## Luau Language Mastery\n" + BRAINS["brain2"][:70000])
    
    if BRAINS["brain3"]:
        knowledge_sections.append("## Expert Patterns & Techniques\n" + BRAINS["brain3"][:90000])
    
    if BRAINS["brain4"]:
        knowledge_sections.append("## Performance & Optimization Excellence\n" + BRAINS["brain4"][:120000])
    
    if BRAINS["brain5"]:
        # Brain 5 is Claude-level - use maximum knowledge
        knowledge_sections.append("## CLAUDE-LEVEL EXPERTISE - Complete Mastery\n" + BRAINS["brain5"][:200000])
    
    if knowledge_sections:
        base_prompt += "\n\n---\n\nDEEP EXPERT KNOWLEDGE:\n\n" + "\n\n".join(knowledge_sections)
        base_prompt += "\n\n---\n\nApply every technique and optimization to create truly exceptional code at Claude Sonnet 4.5 / Opus level."
    
    return base_prompt


# Build all prompts with brain knowledge
print("[EmberA] Building AI prompts with brain knowledge...")
normal_prompt = build_normal_prompt()
hardthink_prompt = build_hardthink_prompt()
script_prompt = build_script_prompt()
hardthink_script_prompt = build_hardthink_script_prompt()

print(f"[EmberA] ✓ Normal prompt: {len(normal_prompt):,} chars")
print(f"[EmberA] ✓ Hard Think prompt: {len(hardthink_prompt):,} chars")
print(f"[EmberA] ✓ Script prompt: {len(script_prompt):,} chars")
print(f"[EmberA] ✓ Hard Think Script prompt: {len(hardthink_script_prompt):,} chars")
print()

# ----------------------------
# MODEL INITIALIZATION
# ----------------------------

print("[EmberA] Loading AI model...")
tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
)

model = AutoModelForCausalLM.from_pretrained(
    model_id,
    device_map="auto",
    quantization_config=bnb_config,
    trust_remote_code=True,
)

model.eval()
print("[EmberA] ✓ Model loaded successfully\n")

app = FastAPI(title="EmberA")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

pending_requests = []
plugin_connected = False
last_ping = 0
ping_timeout = 6


class ChatRequest(BaseModel):
    message: str
    hardThink: bool = False  # New parameter for Hard Think mode


# ----------------------------
# ENHANCED SCRIPT NAME GENERATION
# ----------------------------
def generate_smart_script_name(user_text: str, script_code: str = "") -> str:
    """
    Generate intelligent script names based on user intent and code content
    """
    lowered = user_text.lower()
    
    # First check for explicit name in user message
    name_match = re.search(r"(?:name|call)(?:\s+the\s+script|\s+it)\s*[:=]?\s*['\"]?(\w+)['\"]?", user_text, re.I)
    if name_match:
        return name_match.group(1)
    
    name_match = re.search(r"(?:script|file)\s+(?:called|named)\s+['\"]?(\w+)['\"]?", user_text, re.I)
    if name_match:
        return name_match.group(1)
    
    # Analyze user intent
    intent_patterns = {
        "KillScript": ["kill", "death", "die", "eliminate"],
        "DoorScript": ["door", "open door", "close door", "toggle door"],
        "TeleportScript": ["teleport", "tp", "transport"],
        "GuiScript": ["gui", "ui", "interface", "menu", "button"],
        "ToolScript": ["tool", "weapon", "item"],
        "MovementScript": ["move", "walk", "run", "jump", "fly"],
        "DamageScript": ["damage", "hurt", "health"],
        "SpawnScript": ["spawn", "respawn", "create"],
        "TweenScript": ["tween", "animate", "smooth"],
        "LeaderboardScript": ["leaderboard", "stats", "score"],
        "ChatScript": ["chat", "message", "send"],
        "SoundScript": ["sound", "music", "audio", "play sound"],
        "LightingScript": ["lighting", "light", "brightness"],
        "TimerScript": ["timer", "countdown", "wait"],
        "ProximityScript": ["proximity", "near", "distance", "range"],
        "ClickScript": ["click", "mouse", "detector"],
        "CollectScript": ["collect", "pickup", "grab"],
        "ShopScript": ["shop", "store", "buy", "purchase"],
        "AdminScript": ["admin", "command", "kick", "ban"],
        "DataScript": ["data", "save", "load", "datastore"],
    }
    
    for script_name, keywords in intent_patterns.items():
        if any(keyword in lowered for keyword in keywords):
            return script_name
    
    # Analyze code content if provided
    if script_code:
        code_lower = script_code.lower()
        
        # Check for specific services/APIs used
        if "touched" in code_lower or "touchended" in code_lower:
            return "TouchScript"
        if "clickdetector" in code_lower:
            return "ClickDetectorScript"
        if "proximityprompt" in code_lower:
            return "ProximityScript"
        if "tweenservice" in code_lower:
            return "TweenScript"
        if "datastore" in code_lower or "datastoreservice" in code_lower:
            return "DataScript"
        if "remoteevent" in code_lower or "remotefunction" in code_lower:
            return "RemoteScript"
        if "runservice" in code_lower and "heartbeat" in code_lower:
            return "LoopScript"
        if "userinputservice" in code_lower:
            return "InputScript"
        if "humanoid" in code_lower and "health" in code_lower:
            return "HealthScript"
        if "screengui" in code_lower or "textlabel" in code_lower:
            return "GuiScript"
        
        # Check for common function names
        function_match = re.search(r"function\s+(\w+)\s*\(", script_code, re.I)
        if function_match:
            func_name = function_match.group(1)
            if func_name not in ["new", "init", "setup"]:
                return f"{func_name.capitalize()}Script"
    
    # Check for object types in user message
    object_patterns = {
        "PartScript": ["part"],
        "ModelScript": ["model"],
        "NPCScript": ["npc", "character"],
        "VehicleScript": ["car", "vehicle", "drive"],
        "PetScript": ["pet", "companion"],
        "WeaponScript": ["weapon", "gun", "sword"],
    }
    
    for script_name, keywords in object_patterns.items():
        if any(keyword in lowered for keyword in keywords):
            return script_name
    
    # If all else fails, try to extract a descriptive word
    descriptive_words = re.findall(r'\b(make|create|add|build|script)\s+(?:a|an|the)?\s*(\w+)', lowered)
    if descriptive_words:
        word = descriptive_words[0][1]
        if len(word) > 3 and word not in ["that", "this", "script", "code"]:
            return f"{word.capitalize()}Script"
    
    return "CustomScript"


# ----------------------------
# OPERATION DETECTION & PARSING
# ----------------------------
def detect_operation_type(text: str) -> str:
    """Detect what type of operation the user wants"""
    lowered = text.lower()
    
    # Edit existing script
    edit_phrases = ["edit", "modify", "change", "update", "fix", "add to", "remove from", "improve"]
    script_refs = ["script", "code", "the script", "this script", "that script"]
    if any(phrase in lowered for phrase in edit_phrases) and any(ref in lowered for ref in script_refs):
        return "edit_script"
    
    # Create new script
    create_phrases = ["generate a script", "create a script", "make a script", "write a script", 
                     "build a script", "code a script", "script for", "script that", "new script",
                     "make me a script", "can you make", "can you create", "can you write"]
    if any(phrase in lowered for phrase in create_phrases):
        return "create_script"
    
    # Modify properties
    property_phrases = ["set the", "change the", "make it", "modify the", "update the"]
    property_words = ["color", "transparency", "size", "position", "rotation", "material", 
                     "anchored", "cancollide", "name", "parent", "brightness", "range"]
    if any(phrase in lowered for phrase in property_phrases) and any(word in lowered for word in property_words):
        return "modify_properties"
    
    # Create instance
    instance_phrases = ["create a", "make a", "add a", "insert a", "spawn a"]
    instance_types = ["part", "model", "folder", "gui", "frame", "textlabel", "textbutton", 
                     "tool", "attachment", "beam", "particle", "sound", "light"]
    if any(phrase in lowered for phrase in instance_phrases) and any(itype in lowered for itype in instance_types):
        return "create_instance"
    
    # Delete instance
    delete_phrases = ["delete", "remove", "destroy"]
    if any(phrase in lowered for phrase in delete_phrases):
        return "delete_instance"
    
    # Clone instance
    if "clone" in lowered or "duplicate" in lowered or "copy" in lowered:
        return "clone_instance"
    
    return "chat"


def parse_instance_path(text: str) -> str:
    """Extract instance path from user message"""
    match = re.search(r"(?:in|at|from)\s+([A-Za-z0-9_.]+(?:\.[A-Za-z0-9_]+)*)", text)
    if match:
        return match.group(1)
    
    if "workspace" in text.lower():
        match = re.search(r"(?:part|model|object|instance)\s+(?:called|named)\s+['\"]?([A-Za-z0-9_]+)['\"]?", text, re.I)
        if match:
            return f"Workspace.{match.group(1)}"
        return "Workspace"
    
    return ""


def parse_properties(text: str) -> dict:
    """Extract property changes from user message"""
    properties = {}
    lowered = text.lower()
    
    # Color
    color_match = re.search(r"(?:color|colour)\s+(?:to\s+)?(?:rgb\s*)?\(?(\d+),\s*(\d+),\s*(\d+)\)?", lowered)
    if color_match:
        properties["Color"] = f"Color3.fromRGB({color_match.group(1)}, {color_match.group(2)}, {color_match.group(3)})"
    elif "red" in lowered:
        properties["Color"] = "Color3.fromRGB(255, 0, 0)"
    elif "blue" in lowered:
        properties["Color"] = "Color3.fromRGB(0, 0, 255)"
    elif "green" in lowered:
        properties["Color"] = "Color3.fromRGB(0, 255, 0)"
    
    # Transparency
    trans_match = re.search(r"transparency\s+(?:to\s+)?(\d*\.?\d+)", lowered)
    if trans_match:
        properties["Transparency"] = trans_match.group(1)
    elif "transparent" in lowered or "invisible" in lowered:
        properties["Transparency"] = "1"
    elif "opaque" in lowered or "visible" in lowered:
        properties["Transparency"] = "0"
    
    # Size
    size_match = re.search(r"size\s+(?:to\s+)?(?:vector3\.new\s*)?\(?(\d+),\s*(\d+),\s*(\d+)\)?", lowered)
    if size_match:
        properties["Size"] = f"Vector3.new({size_match.group(1)}, {size_match.group(2)}, {size_match.group(3)})"
    
    # Position
    pos_match = re.search(r"position\s+(?:to\s+)?(?:vector3\.new\s*)?\(?(-?\d+),\s*(-?\d+),\s*(-?\d+)\)?", lowered)
    if pos_match:
        properties["Position"] = f"Vector3.new({pos_match.group(1)}, {pos_match.group(2)}, {pos_match.group(3)})"
    
    # Anchored
    if "anchored" in lowered:
        if "not anchored" in lowered or "unanchored" in lowered:
            properties["Anchored"] = "false"
        else:
            properties["Anchored"] = "true"
    
    # CanCollide
    if "cancollide" in lowered or "can collide" in lowered:
        if "can't collide" in lowered or "cannot collide" in lowered:
            properties["CanCollide"] = "false"
        else:
            properties["CanCollide"] = "true"
    
    # Name
    name_match = re.search(r"name\s+(?:to\s+)?['\"]([A-Za-z0-9_]+)['\"]", lowered)
    if name_match:
        properties["Name"] = f'"{name_match.group(1)}"'
    
    # Material
    materials = ["plastic", "wood", "slate", "concrete", "brick", "metal", "grass", 
                "sand", "fabric", "granite", "marble", "ice", "neon", "glass"]
    for mat in materials:
        if mat in lowered:
            properties["Material"] = f"Enum.Material.{mat.capitalize()}"
            break
    
    # Brightness
    bright_match = re.search(r"brightness\s+(?:to\s+)?(\d*\.?\d+)", lowered)
    if bright_match:
        properties["Brightness"] = bright_match.group(1)
    
    # Range
    range_match = re.search(r"range\s+(?:to\s+)?(\d+)", lowered)
    if range_match:
        properties["Range"] = range_match.group(1)
    
    return properties


def parse_instance_type(text: str) -> str:
    """Determine what type of instance to create"""
    lowered = text.lower()
    
    type_mapping = {
        "part": "Part",
        "wedge": "WedgePart",
        "sphere": "SpherePart",
        "cylinder": "Cylinder",
        "folder": "Folder",
        "model": "Model",
        "gui": "ScreenGui",
        "frame": "Frame",
        "textlabel": "TextLabel",
        "textbutton": "TextButton",
        "imagebutton": "ImageButton",
        "imagelabel": "ImageLabel",
        "tool": "Tool",
        "sound": "Sound",
        "pointlight": "PointLight",
        "spotlight": "SpotLight",
        "surfacelight": "SurfaceLight",
        "particle": "ParticleEmitter",
        "beam": "Beam",
        "attachment": "Attachment",
        "script": "Script",
        "localscript": "LocalScript",
    }
    
    for key, value in type_mapping.items():
        if key in lowered:
            return value
    
    return "Part"


def parse_service(text: str) -> str:
    """Extract target service from user message"""
    mapping = {
        "workspace": "Workspace",
        "replicatedstorage": "ReplicatedStorage",
        "replicated storage": "ReplicatedStorage",
        "server script service": "ServerScriptService",
        "serverscriptservice": "ServerScriptService",
        "sss": "ServerScriptService",
        "starter player scripts": "StarterPlayer.StarterPlayerScripts",
        "starterplayerscripts": "StarterPlayer.StarterPlayerScripts",
        "starter character scripts": "StarterPlayer.StarterCharacterScripts",
        "startercharacterscripts": "StarterPlayer.StarterCharacterScripts",
        "startergui": "StarterGui",
        "starter gui": "StarterGui",
        "replicatedfirst": "ReplicatedFirst",
        "replicated first": "ReplicatedFirst",
        "lighting": "Lighting",
        "players": "Players",
    }

    lowered = text.lower()
    for key, value in mapping.items():
        if key in lowered:
            return value

    if "local" in lowered or "client" in lowered or "gui" in lowered:
        return "StarterPlayer.StarterPlayerScripts"
    
    return "ServerScriptService"


def parse_script_type(text: str) -> str:
    """Determine if Script, LocalScript, or ModuleScript"""
    lowered = text.lower()
    
    if "module" in lowered:
        return "ModuleScript"
    elif "local" in lowered or "client" in lowered:
        return "LocalScript"
    else:
        return "Script"


def is_plugin_alive() -> bool:
    """Check if Roblox plugin is connected"""
    global plugin_connected, last_ping

    if not plugin_connected:
        return False

    if time.time() - last_ping > ping_timeout:
        plugin_connected = False
        return False

    return True


def generate_response(user_text: str, script_mode: bool, hard_think: bool = False) -> str:
    """Generate AI response based on mode"""
    # Select appropriate system prompt
    if script_mode:
        system = hardthink_script_prompt if hard_think else script_prompt
    else:
        system = hardthink_prompt if hard_think else normal_prompt

    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user_text},
    ]

    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    input_len = inputs["input_ids"].shape[1]

    # Adjust generation parameters for Hard Think mode
    if hard_think:
        temp = 0.3 if script_mode else 0.7
        tokens = max_new_tokens_hardthink
        top_p = 0.95
        top_k = 60
    else:
        temp = 0.15 if script_mode else 0.5
        tokens = max_new_tokens
        top_p = 0.9
        top_k = 50

    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=tokens,
            temperature=temp,
            top_p=top_p,
            top_k=top_k,
            repetition_penalty=1.15,
            do_sample=True,
        )

    text = tokenizer.decode(
        output[0][input_len:],
        skip_special_tokens=True
    ).strip()

    if script_mode:
        text = re.sub(r'```(?:lua|luau)?\n?', '', text)
        text = text.strip()
    
    return text if text else "I'm ready to help! What would you like to know?"


# ----------------------------
# ROUTES
# ----------------------------
@app.post("/chat")
def chat(req: ChatRequest):
    operation = detect_operation_type(req.message)
    summary = None
    response = ""
    hard_think = req.hardThink
    
    # Log hard think requests
    if hard_think:
        print(f"[EmberA] 🧠 Hard Think Mode activated for: {req.message[:50]}...")
    
    if operation == "chat":
        response = generate_response(req.message, False, hard_think)
    
    elif operation == "create_script":
        response = generate_response(req.message, True, hard_think)
        script_type = parse_script_type(req.message)
        service = parse_service(req.message)
        script_name = generate_smart_script_name(req.message, response)
        
        if is_plugin_alive():
            pending_requests.append({
                "id": str(uuid.uuid4()),
                "operation": "create_script",
                "service": service,
                "scriptName": script_name,
                "scriptType": script_type,
                "scriptSource": response,
            })
            
            mode_note = "Advanced optimizations applied" if hard_think else "Script queued for plugin insertion"
            summary = {
                "summary": f"Script '{script_name}' generated",
                "created": [f"{script_type} in {service}"],
                "updated": [],
                "notes": [mode_note],
            }
        else:
            summary = {
                "summary": "Script generated (plugin offline)",
                "created": [],
                "updated": [],
                "notes": ["Connect the Roblox Studio plugin to auto-insert scripts"],
            }
    
    elif operation == "edit_script":
        response = generate_response(req.message, True, hard_think)
        script_path = parse_instance_path(req.message)
        
        if not script_path:
            script_name_match = re.search(r"(?:script|file)\s+(?:called|named)\s+['\"]?([A-Za-z0-9_]+)['\"]?", req.message, re.I)
            if script_name_match:
                script_path = script_name_match.group(1)
        
        if is_plugin_alive():
            pending_requests.append({
                "id": str(uuid.uuid4()),
                "operation": "edit_script",
                "scriptPath": script_path or "",
                "newSource": response,
            })
            
            summary = {
                "summary": f"Script edit queued",
                "created": [],
                "updated": [script_path or "Selected script"],
                "notes": ["Script will be updated in Studio"],
            }
        else:
            summary = {
                "summary": "Script edit generated (plugin offline)",
                "created": [],
                "updated": [],
                "notes": ["Connect plugin to apply changes"],
            }
    
    elif operation == "modify_properties":
        properties = parse_properties(req.message)
        instance_path = parse_instance_path(req.message)
        
        response = f"Modifying properties: {', '.join(properties.keys())}"
        
        if is_plugin_alive() and properties:
            pending_requests.append({
                "id": str(uuid.uuid4()),
                "operation": "modify_properties",
                "instancePath": instance_path,
                "properties": properties,
            })
            
            summary = {
                "summary": "Property changes queued",
                "created": [],
                "updated": [instance_path or "Selected object"],
                "notes": [f"Properties: {', '.join(properties.keys())}"],
            }
        else:
            response = "Please connect the plugin to modify properties, or provide more details."
    
    elif operation == "create_instance":
        instance_type = parse_instance_type(req.message)
        parent_path = parse_instance_path(req.message) or "Workspace"
        instance_name = re.search(r"(?:named|called)\s+['\"]?([A-Za-z0-9_]+)['\"]?", req.message, re.I)
        instance_name = instance_name.group(1) if instance_name else instance_type
        
        properties = parse_properties(req.message)
        
        response = f"Creating {instance_type} named '{instance_name}' in {parent_path}"
        
        if is_plugin_alive():
            pending_requests.append({
                "id": str(uuid.uuid4()),
                "operation": "create_instance",
                "instanceType": instance_type,
                "instanceName": instance_name,
                "parentPath": parent_path,
                "properties": properties,
            })
            
            summary = {
                "summary": f"Creating {instance_type}",
                "created": [f"{instance_name} in {parent_path}"],
                "updated": [],
                "notes": [f"Type: {instance_type}"],
            }
        else:
            response += " (plugin offline)"
    
    elif operation == "delete_instance":
        instance_path = parse_instance_path(req.message)
        
        response = f"Deleting {instance_path or 'selected object'}"
        
        if is_plugin_alive():
            pending_requests.append({
                "id": str(uuid.uuid4()),
                "operation": "delete_instance",
                "instancePath": instance_path,
            })
            
            summary = {
                "summary": "Deletion queued",
                "created": [],
                "updated": [],
                "notes": [f"Will delete: {instance_path or 'selected object'}"],
            }
        else:
            response += " (plugin offline)"
    
    elif operation == "clone_instance":
        instance_path = parse_instance_path(req.message)
        
        response = f"Cloning {instance_path or 'selected object'}"
        
        if is_plugin_alive():
            pending_requests.append({
                "id": str(uuid.uuid4()),
                "operation": "clone_instance",
                "instancePath": instance_path,
            })
            
            summary = {
                "summary": "Clone queued",
                "created": ["Clone of selected object"],
                "updated": [],
                "notes": ["Clone will be created"],
            }
        else:
            response += " (plugin offline)"

    return {
        "type": "chat",
        "response": response,
        "summaryBoxes": summary,
        "pluginConnected": is_plugin_alive(),
        "hardThinkMode": hard_think
    }


@app.get("/getPendingScriptRequest")
def get_pending():
    """Plugin polls this endpoint for queued operations"""
    if not is_plugin_alive():
        return {}

    if not pending_requests:
        return {}

    return pending_requests.pop(0)


@app.api_route("/pluginConnected", methods=["GET", "POST"])
def plugin_connected_endpoint():
    """Plugin pings this to maintain connection"""
    global plugin_connected, last_ping
    plugin_connected = True
    last_ping = time.time()
    return {"status": "connected"}


@app.get("/getstatus")
def get_status():
    """Check plugin connection status"""
    return {"connected": is_plugin_alive()}


if __name__ == "__main__":
    print("=" * 70)
    print("  EMBERA AI SERVICE - CLAUDE-LEVEL ROBLOX EXPERTISE")
    print("=" * 70)
    print(f"  Server running on http://127.0.0.1:9600")
    print(f"  Device: {device.upper()}")
    print(f"  Model: {model_id}")
    print(f"  Brains loaded: {loaded_count}/5")
    print(f"  🧠 Brain 5: Ultimate Mastery ({len(BRAINS['brain5']):,} chars)")
    print(f"  🧠 Hard Think Mode: ENABLED")
    print("=" * 70)
    uvicorn.run(app, host="127.0.0.1", port=9600)